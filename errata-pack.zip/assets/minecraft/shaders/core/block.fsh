#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:errata_flash.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec4 errTint;
in vec3 errView;
in vec3 errNormal;
flat in float errOn;

out vec4 fragColor;

void main() {
    vec4 albedo = texture(Sampler0, texCoord0);
    vec4 color = albedo * vertexColor * ColorModulator;
    vec3 flash = albedo.rgb * errTint.rgb * ColorModulator.rgb * errata_flash_light(errView, errNormal, errOn, GameTime);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif
    float fogValue = total_fog_value(sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd);
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
    fragColor.rgb += flash * (1.0 - 0.6 * fogValue);
    fragColor.rgb = errata_film(fragColor.rgb, gl_FragCoord.xy, ScreenSize, GameTime);
}
