#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:errata_spot.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec3 spotBaseColor;
in vec3 spotPosition;
in vec3 spotNormal;
flat in float spotWorld;

out vec4 fragColor;

void main() {
    vec4 albedo = texture(Sampler0, texCoord0);
    vec4 color = albedo * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    vec3 flash = (GameTime < 0.0 && spotWorld > 0.5)
        ? albedo.rgb * spotBaseColor * ColorModulator.rgb * errata_spot(spotPosition, spotNormal, GameTime)
        : vec3(0.0);
    float fogValue = total_fog_value(sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd);
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
    if (GameTime < 0.0 && spotWorld > 0.5) {
        fragColor.rgb += flash * (1.0 - 0.55 * fogValue);
    }
}
