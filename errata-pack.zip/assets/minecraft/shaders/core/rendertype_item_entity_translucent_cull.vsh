#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;
out vec3 spotBaseColor;
out vec3 spotPosition;
out vec3 spotNormal;
flat out float spotWorld;

void main() {
    vec4 viewPos = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * viewPos;

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vec4 lit = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    vertexColor = lit * texelFetch(Sampler2, UV2 / 16, 0);
    spotBaseColor = lit.rgb;
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
    spotPosition = viewPos.xyz;
    spotNormal = mat3(ModelViewMat) * Normal;
    spotWorld = (ProjMat[3][3] < 0.5 && length(viewPos.xyz) > 0.35) ? 1.0 : 0.0;
}
