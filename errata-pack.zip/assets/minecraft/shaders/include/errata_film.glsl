#version 330

vec3 errata_film(vec3 color, vec2 fragCoord, vec2 screen, float gameTime) {
    float n = fract(sin(dot(fragCoord + fract(gameTime * 4000.0) * 91.7, vec2(12.9898, 78.233))) * 43758.5453);
    vec2 uv = fragCoord / max(screen, vec2(1.0)) - 0.5;
    float vig = 1.0 - smoothstep(0.32, 0.85, length(uv * vec2(1.15, 1.0))) * 0.5;
    return max(vec3(0.0), color * vig + (n - 0.5) * 0.022);
}
