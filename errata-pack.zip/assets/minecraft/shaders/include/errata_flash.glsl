#version 330

// A camera-local cone and spill inspired by Found Footage's two-light setup. Vanilla core shaders have no shadow
// map or previous camera transform, so this beam uses only surface normals, distance and a slight handheld drift.
// The server turns it on by giving the player an
// invisible Night Vision effect; lightmap.fsh stores NightVisionFactor in the unused sky-15/block-0 texel of the
// lightmap, and every world shader reads it back here.

float errata_flash_on(sampler2D lightMap) {
    return texelFetch(lightMap, ivec2(0, 15), 0).r;
}

const vec3 ERRATA_BEAM = vec3(1.0, 0.97, 0.90);
const vec3 ERRATA_ORIGIN = vec3(0.18, -0.15, -0.14);

vec3 errata_axis(float gameTime) {
    float t = gameTime * 1200.0;
    return normalize(vec3(sin(t * 1.7) * 0.012 - 0.014, cos(t * 1.31) * 0.009 - 0.035, -1.0));
}

// viewPos: view-space position (camera at origin, looking down -Z). viewNormal: view-space normal (may be zero).
vec3 errata_flash_light(vec3 viewPos, vec3 viewNormal, float on, float gameTime) {
    if (on <= 0.001) return vec3(0.0);
    vec3 fromLight = viewPos - ERRATA_ORIGIN;
    float d = length(fromLight);
    if (d < 0.0001) return vec3(0.0);
    vec3 toFrag = fromLight / d;
    float c = dot(toFrag, errata_axis(gameTime));
    float cone = smoothstep(0.962, 0.987, c);
    float core = smoothstep(0.987, 0.999, c);
    float spill = smoothstep(0.54, 0.975, c) * (1.0 - smoothstep(5.0, 14.0, d));
    float att = (1.0 - smoothstep(18.0, 29.0, d)) / (1.0 + 0.0021 * d * d);
    float facing = 1.0;
    if (dot(viewNormal, viewNormal) > 0.01) {
        facing = 0.33 + 0.67 * max(0.0, dot(normalize(viewNormal), -toFrag));
    }
    float hand = (1.0 - smoothstep(0.0, 1.8, d)) * 0.05;
    float l = ((cone * 2.9 + core * 1.35) * att * facing + 0.10 * spill + hand) * on;      // light only where you point
    return (1.0 - exp(-l)) * ERRATA_BEAM;
}

// light scattered back toward the eye inside the beam: a visible shaft that fades with distance into the dark
vec3 errata_flash_haze(vec3 viewPos, float on, float gameTime) {
    if (on <= 0.001) return vec3(0.0);
    vec3 fromLight = viewPos - ERRATA_ORIGIN;
    float d = length(fromLight);
    float c = dot(fromLight / max(d, 0.0001), errata_axis(gameTime));
    float beam = smoothstep(0.965, 0.997, c);
    float depth = (1.0 - exp(-d / 5.0)) * (1.0 - smoothstep(10.0, 33.0, d));
    return beam * depth * 0.042 * on * ERRATA_BEAM;
}

// found-footage grain and a soft vignette, applied last to the final colour
vec3 errata_film(vec3 color, vec2 fragCoord, vec2 screen, float gameTime) {
    float n = fract(sin(dot(fragCoord + fract(gameTime * 4000.0) * 91.7, vec2(12.9898, 78.233))) * 43758.5453);
    vec2 uv = fragCoord / max(screen, vec2(1.0)) - 0.5;
    float vig = 1.0 - smoothstep(0.32, 0.85, length(uv * vec2(1.15, 1.0))) * 0.5;
    return max(vec3(0.0), color * vig + (n - 0.5) * 0.022);
}
