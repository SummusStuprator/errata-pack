#version 330

// Light the albedo on the hit face before the world's ordinary fog is applied.
vec3 errata_spot(vec3 surface, vec3 normal) {
    const vec3 lens = vec3(0.16, -0.19, -0.24);
    vec3 ray = surface - lens;
    float distance = length(ray);
    if (distance < 0.02 || distance > 24.0) return vec3(0.0);
    vec3 heading = ray / distance;
    vec3 axis = normalize(vec3(0.0, 0.0, -12.0) - lens);
    float angle = dot(heading, axis);
    float edge = smoothstep(0.9825, 0.9905, angle);
    float core = smoothstep(0.989, 0.9994, angle);
    float attenuation = (1.0 - smoothstep(12.0, 24.0, distance)) / (1.0 + 0.0025 * distance * distance);
    float facing = dot(normal, normal) > 0.01 ? 0.26 + 0.74 * max(0.0, dot(normalize(normal), -heading)) : 1.0;
    return vec3(1.0, 0.985, 0.95) * (edge * 1.18 + core * 0.53) * attenuation * facing;
}
