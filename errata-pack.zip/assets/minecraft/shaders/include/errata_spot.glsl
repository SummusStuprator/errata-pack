#version 330

// Pure circular handheld flashlight optics: warm-ivory core, wide smooth reflector cone,
// subtle optical bezel ring, gentle close-range spill, and subtle dust scatter in the beam.

float errata_spot_clock(float gameTime) {
    return gameTime < 0.0 ? (1.0 + gameTime) : gameTime;
}

vec3 errata_spot_axis(float gameTime) {
    float t = errata_spot_clock(gameTime) * 1200.0;
    const vec3 lens = vec3(0.16, -0.17, -0.18);
    vec3 aim = vec3(sin(t * 1.45) * 0.09, cos(t * 1.13) * 0.07 - 0.14, -14.0);
    return normalize(aim - lens);
}

vec3 errata_spot(vec3 surface, vec3 normal, float gameTime) {
    const vec3 lens = vec3(0.16, -0.17, -0.18);
    vec3 ray = surface - lens;
    float d = length(ray);
    if (d < 0.04 || d > 28.0) return vec3(0.0);
    vec3 heading = ray / d;
    vec3 axis = errata_spot_axis(gameTime);
    float c = dot(heading, axis);

    // Wide realistic circular cone with smooth optical penumbra, bright hotspot, and faint lens bezel ring
    float cone = smoothstep(0.946, 0.985, c);
    float core = smoothstep(0.984, 0.9985, c);
    float rim = exp(-pow((c - 0.953) / 0.0040, 2.0)) * 0.14;
    float spill = smoothstep(0.84, 0.960, c) * (1.0 - smoothstep(1.8, 6.5, d)) * 0.04;

    float att = (1.0 - smoothstep(16.0, 28.0, d)) / (1.0 + 0.0024 * d * d);
    float facing = dot(normal, normal) > 0.01
        ? 0.26 + 0.74 * max(0.0, dot(normalize(normal), -heading))
        : 1.0;

    float mainPower = (cone * 2.35 + core * 1.55 + rim) * att * facing;
    float total = mainPower + spill * facing;
    if (total <= 0.0001) return vec3(0.0);

    // Subtle glass-lens temperature shift: warm ivory core, slightly cooler dusty rim
    vec3 coreTint = vec3(1.0, 0.965, 0.89);
    vec3 edgeTint = vec3(0.91, 0.94, 0.98);
    vec3 tint = mix(edgeTint, coreTint, smoothstep(0.948, 0.988, c));
    return (1.0 - exp(-total)) * tint;
}

// Subtle airborne dust scattered inside the beam shaft
vec3 errata_spot_haze(vec3 surface, float gameTime) {
    const vec3 lens = vec3(0.16, -0.17, -0.18);
    vec3 ray = surface - lens;
    float d = length(ray);
    if (d < 0.2 || d > 28.0) return vec3(0.0);
    float c = dot(ray / d, errata_spot_axis(gameTime));
    float shaft = smoothstep(0.955, 0.995, c);
    float depth = (1.0 - exp(-d / 6.0)) * (1.0 - smoothstep(12.0, 28.0, d));
    return shaft * depth * 0.030 * vec3(1.0, 0.97, 0.90);
}
